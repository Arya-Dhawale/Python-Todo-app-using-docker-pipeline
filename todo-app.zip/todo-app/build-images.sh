#!/bin/bash
set -e

echo "[*] Pointing Docker to Minikube daemon..."
eval $(minikube docker-env)

echo "[*] Ensuring base Python image is available..."
if ! docker images | grep -q "python.*3.11-slim"; then
    echo "[!] Base image not found locally, loading from python311.tar..."
    docker load < python311.tar
fi

echo "[*] Building todo-app image (offline)..."
cd todo-app        # make sure build context is todo-app/
docker build -t todo-app:latest .
cd ..

