#!/bin/bash
set -e

NAMESPACE=cyber-todo

echo "[*] Starting Minikube if not already running..."
if ! minikube status | grep -q "host: Running"; then
    minikube start
fi

echo "[*] Creating namespace: $NAMESPACE"
kubectl create namespace $NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

echo "[*] Deleting old pg-init job (if exists)..."
kubectl delete job pg-init -n $NAMESPACE --ignore-not-found

echo "[*] Deploying all Kubernetes resources in k8s/..."
kubectl apply -f k8s/ -n $NAMESPACE

echo "[+] All components deployed! 🚀"
echo "You can check services with: minikube service -n $NAMESPACE --all"

echo "[*] Opening exposed NodePort services in Firefox..."
URLS=$(minikube service -n $NAMESPACE --all --url)
if [ -n "$URLS" ]; then
    for url in $URLS; do
        firefox "$url" &
    done
else
    echo "[!] No NodePort services found to open."
fi
