#!/bin/bash
set -e

NAMESPACE=cyber-todo

echo "[*] Creating namespace: $NAMESPACE"
kubectl create namespace $NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

echo "[*] Deleting old pg-init job (if exists)..."
kubectl delete job pg-init -n $NAMESPACE --ignore-not-found

echo "[*] Deploying all Kubernetes resources in k8s/..."
kubectl apply -f k8s/ -n $NAMESPACE

echo "[+] All components deployed! 🚀"
echo "You can check services with: minikube service -n $NAMESPACE --all"
