#!/bin/bash
set -e

NAMESPACE=cyber-todo

echo "[*] Deleting all resources in namespace: $NAMESPACE"
kubectl delete namespace $NAMESPACE --ignore-not-found

echo "[*] Stopping Minikube cluster..."
minikube stop

echo "[+] Cluster stopped and namespace removed."

