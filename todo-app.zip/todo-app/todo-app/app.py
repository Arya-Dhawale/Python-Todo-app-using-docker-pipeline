from flask import Flask, request, jsonify, send_from_directory
import os, psycopg2, json
from prometheus_client import Counter, generate_latest, CollectorRegistry, CONTENT_TYPE_LATEST

app = Flask(__name__, static_folder='static', static_url_path='/static')

DB_HOST = os.environ.get('POSTGRES_HOST','postgres')
DB_NAME = os.environ.get('POSTGRES_DB','todo')
DB_USER = os.environ.get('POSTGRES_USER','todo_user')
DB_PASS = os.environ.get('POSTGRES_PASSWORD','todo_pass')

# Prometheus metric
TODO_CREATED = Counter('todo_created_total', 'Total TODOs created')

def get_db():
    conn = psycopg2.connect(host=DB_HOST, dbname=DB_NAME, user=DB_USER, password=DB_PASS)
    return conn

@app.route('/metrics')
def metrics():
    return generate_latest(), 200, {'Content-Type': CONTENT_TYPE_LATEST}

@app.route('/api/todos', methods=['GET'])
def list_todos():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, title, done FROM todos ORDER BY id DESC")
    rows = cur.fetchall()
    cur.close(); conn.close()
    items = [{'id':r[0],'title':r[1],'done':bool(r[2])} for r in rows]
    return jsonify(items)

@app.route('/api/todos', methods=['POST'])
def create_todo():
    data = request.get_json() or {}
    title = data.get('title')
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO todos(title,done) VALUES (%s,%s) RETURNING id", (title, False))
    tid = cur.fetchone()[0]
    conn.commit()
    cur.close(); conn.close()
    TODO_CREATED.inc()
    return jsonify({'id': tid, 'title': title, 'done': False}), 201

@app.route('/api/todos/<int:tid>', methods=['PUT'])
def update_todo(tid):
    data = request.get_json() or {}
    done = data.get('done', False)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE todos SET done=%s WHERE id=%s", (done, tid))
    conn.commit()
    cur.close(); conn.close()
    return jsonify({'status':'ok'})

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
