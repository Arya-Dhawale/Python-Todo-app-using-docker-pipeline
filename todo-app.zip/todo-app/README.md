
# Services - ToDo Demo (Minikube)

This package contains a lightweight To-Do application with Postgres, pgAdmin, Prometheus and Grafana, ready for Minikube.

Components:
- todo-app (Flask REST + simple SPA frontend)
- postgres (database)
- pgAdmin (DB admin UI)
- Prometheus (monitoring)
- Grafana (dashboard)
- k8s manifests and start/stop scripts

Quick start:
1. Start minikube:
   minikube start --driver=docker --memory=4096 --cpus=2
   eval $(minikube -p minikube docker-env)

2. Build images:
   chmod +x build-images.sh
   ./build-images.sh

3. Deploy:
   chmod +x start.sh
   ./start.sh

4. Check pods:
   kubectl get pods -n todo-demo -w

5. Access services:
   - ToDo app (NodePort): run `minikube service todo-service -n todo-demo`
   - pgAdmin (NodePort): run `minikube service pgadmin -n todo-demo`
     default login: user@local (email) / admin (password defined in manifests)
   - Grafana: `minikube service grafana -n todo-demo`
   - Prometheus: `minikube service prometheus -n todo-demo`

6. Tear down:
   ./stop.sh

Notes:
- For production, do not use plain secrets; use Vault or sealed-secrets.
- Trivy recommended to scan images before deployment.
