#!/bin/bash
NAMESPACE=todo-demo
kubectl create namespace $NAMESPACE || true
kubectl config set-context --current --namespace=$NAMESPACE
kubectl apply -f k8s/ -n $NAMESPACE
